/*
 * Unit 3 / Assignment 1 / Question 5
 * Graham Carkner - 05/14/2019
 * 
 * EDITS:
 * 05/14/19 - started basic functionality
 * 05/15/19 - worked on edit marks functionality
 * 05/16/19 - Started list marks functionality
 * 05/20/19 - Finished list functionality, finished app
 */
package a3q5.searchsort;

import java.util.Random;
import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

public class A3Q5SearchSort {

    String[] names = new String[50];
    Double[][] scores = new Double[50][50];
    Double[] avgs = new Double[50];
    String[] sortNames = new String[50];
    Double avgHolder;
    String namHolder;
    int nNum = 0;
    int sNum = 1;
    int bAction = 0;
    int nTemp = 0;
    int sTemp = 0;
    String markDisplay = "";
    
    A3Q5SearchSort() {
      JFrame f = new JFrame("STUDENT SORTER+");
      
      //--Global GUI
      
      JLabel Title = new JLabel ("STUDENT SORTER+");
      Title.setBounds(10, 10, 400, 50);
      Title.setFont(new Font("Arial", Font.BOLD, 20));
      
      JLabel Tag = new JLabel ("Your smart student sorting solution!");
      Tag.setBounds(10, 30, 400, 50);
      Tag.setFont(new Font("Arial", Font.PLAIN, 14));
      
      JLabel display = new JLabel("");
       display.setBounds(300, 0, 420, 330);
       display.setBorder(BorderFactory.createLineBorder(Color.black));
       display.setFont(new Font("Arial", Font.PLAIN, 14));
       display.setVerticalAlignment(JLabel.TOP);
       display.setVerticalTextPosition(JLabel.TOP);
      
      //--Home Panel
      
      JPanel homePanel = new JPanel();
      homePanel.setLayout(null);
      homePanel.setSize(800,400);
      homePanel.setBackground(Color.white);
      
      JLabel hInst = new JLabel ("Please select an action:");
      hInst.setBounds(10, 70, 400, 50);
      hInst.setFont(new Font("Arial", Font.PLAIN, 14));
      
      JButton addStudent = new JButton ("Add a student");
      addStudent.setBounds(10, 130, 150, 30);
      
      JButton editStudent = new JButton ("Edit a student");
      editStudent.setBounds(10, 170, 150, 30);
      
      JButton listStudent = new JButton ("List the students");
      listStudent.setBounds(10, 210, 150, 30);
      
      homePanel.add(Title);
      homePanel.add(Tag);
      homePanel.add(hInst);
      homePanel.add(addStudent);
      homePanel.add(editStudent);
      homePanel.add(listStudent);
      
      //--Add Student Panel
      
      JPanel addPanel = new JPanel();
      addPanel.setLayout(null);
      addPanel.setSize(800,400);
      addPanel.setBackground(Color.white);
      addPanel.setVisible(false);
      
      JLabel aInst = new JLabel ("Enter the following information:");
      aInst.setBounds(10, 70, 400, 50);
      aInst.setFont(new Font("Arial", Font.PLAIN, 14));
      
      JTextField aName = new JTextField("Student Name");
      aName.setBounds(10, 120, 150, 25);
      
      JButton aOk = new JButton("ENTER");
      aOk.setBounds(10, 155, 150, 25);
      
      JTextField aScores = new JTextField("");
      aScores.setBounds(10, 120, 150, 25);
      aScores.setVisible(false);
      
      JLabel aHint = new JLabel ("(type 'done' when done.)");
      aHint.setBounds(10, 250, 400, 50);
      aHint.setFont(new Font("Arial", Font.ITALIC, 12));
      aHint.setVisible(false);
      
      addPanel.add(aInst);
      addPanel.add(aName);
      addPanel.add(aScores);
      addPanel.add(aOk);
      addPanel.add(aHint);
      
      //--Edit Student Panel
      
      JPanel editPanel = new JPanel();
      editPanel.setLayout(null);
      editPanel.setSize(800,400);
      editPanel.setBackground(Color.white);
      editPanel.setVisible(false);
      
      JLabel eInst = new JLabel ("Which student do you want to edit:");
      eInst.setBounds(10, 70, 400, 50);
      eInst.setFont(new Font("Arial", Font.PLAIN, 14));
      
      JTextField eInput = new JTextField("Student Name");
      eInput.setBounds(10, 120, 150, 25);
      
      JButton eOk = new JButton("ENTER");
      eOk.setBounds(10, 155, 150, 25);
      
      JLabel eHint = new JLabel ("(note: name is case sensitive)");
      eHint.setBounds(10, 250, 400, 50);
      eHint.setFont(new Font("Arial", Font.ITALIC, 12));
      
      editPanel.add(eInst);
      editPanel.add(eInput);
      editPanel.add(eOk);
      editPanel.add(eHint);
      
      //--List Student Panel
      
      JPanel listPanel = new JPanel();
      listPanel.setLayout(null);
      listPanel.setSize(800,400);
      listPanel.setBackground(Color.white);
      listPanel.setVisible(false);
      
      JLabel lInst = new JLabel ("How to sort the list:");
      lInst.setBounds(10, 70, 400, 50);
      lInst.setFont(new Font("Arial", Font.PLAIN, 14));
      
      JButton lAverage = new JButton("Averages");
      lAverage.setBounds(10, 120, 150, 25);
      
      JButton lAdded = new JButton("Date added");
      lAdded.setBounds(10, 155, 150, 25);
      
      JButton lBack = new JButton("Back");
      lBack.setBounds(10, 190, 150, 25);
      
      JLabel lHint = new JLabel ("(note: name is case sensitive)");
      lHint.setBounds(10, 250, 400, 50);
      lHint.setFont(new Font("Arial", Font.ITALIC, 12));
      
      listPanel.add(lInst);
      listPanel.add(lAverage);
      listPanel.add(lAdded);
      listPanel.add(lBack);
      listPanel.add(lHint);
      
      //--Putting onto JFrame
      
      f.pack();
      f.add(homePanel);
      f.add(addPanel);
      f.add(editPanel);
      f.add(listPanel);
      f.setSize(800,400);
      f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      f.setVisible(true);
      
      //==========ADD STUDENT FUNCTIONALITY==========
      
      addStudent.addActionListener(new ActionListener() {
            @Override	
            public void actionPerformed(ActionEvent arg0) {
                addPanel.add(Title);
                addPanel.add(Tag);
                addPanel.add(display);
                Tag.setText("Add a new student.");
                
                homePanel.setVisible(false);
                addPanel.setVisible(true);
                
                for (int i = 0; i < 50; i++) {
                    if (names[i] == null) {
                    break;
                    }
                    else {
                    markDisplay = markDisplay + names[i] + "<br>";
                    }
                }
                 display.setText("<html>" + "Current students:<br>"+ markDisplay + "</html>");
            }        
      });
      
      aOk.addActionListener(new ActionListener() {
            @Override	
            public void actionPerformed(ActionEvent arg0) {
                
                if (bAction == 0) {
                    boolean nameUse = false;
                    
                    for (int i = 0; i < 50; i++) {
                        if (names[i] == null) {
                            break;
                        }
                        else if (names[i].equals(aName.getText())) {
                            aInst.setText("This student is already in the list.");
                            nameUse = true;
                            break;
                        }
                    }
                    
                    if (nameUse) {nameUse = false;}
                    else{
                        names[nNum] = aName.getText();

                        aName.setVisible(false);
                        aScores.setVisible(true);
                        aHint.setVisible(true);

                        aInst.setText("Enter " + names[nNum] + "'s mark " + (sNum) + " (in %):");
                        markDisplay = names[nNum] + "'s marks:";
                         display.setText(markDisplay);
                        bAction = 1;
                    }
                }
                else {
                    if ("done".equals(aScores.getText())) { 
                        
                        if (sNum == 1) {
                            aInst.setText("Error: You must input at least one mark.");
                            aScores.setText("");
                        }
                        else {
                            scores[nNum][0] = new Double(sNum - 1);

                            sNum = 1;
                            nNum++;
                            bAction = 0;
                            markDisplay = "";

                            aScores.setText("");
                            aName.setText("Student Name");
                            Tag.setText("Your smart student sorting solution!");
                            hInst.setText("Please select an action:");
                            homePanel.add(Title);
                            homePanel.add(Tag);

                            addPanel.setVisible(false);
                            homePanel.setVisible(true);
                            aName.setVisible(true);
                            aScores.setVisible(false);
                            aHint.setVisible(false);

                            aInst.setText("Enter the following information:");
                        }
                    }
                    else {
                        boolean x = true;
                        try {
                            scores[nNum][sNum] = Double.parseDouble(aScores.getText());
                            if (scores[nNum][sNum] > 100) {
                                x = false;
                            }
                        }
                        catch (NumberFormatException e) {
                            x = false;
                        }

                        if (x) {
                            aScores.setText("");
                            markDisplay = markDisplay + "<br>Mark " + sNum + ": " + scores[nNum][sNum] + "%";
                            scores[nNum][0] = new Double(sNum);
                            sNum++;
                            aInst.setText("Enter " + names[nNum] + "'s mark " + (sNum) + " (in %):");
                            display.setText("<html>" + markDisplay + "</html>");
                        } 
                        else {
                            aInst.setText("Invalid score: Please try again.");
                        }
                    }
                }
            }        
      });
      
      //==========EDIT ENTRY FUNCTIONALITY==========
      
      editStudent.addActionListener(new ActionListener() {
            @Override	
            public void actionPerformed(ActionEvent arg0) {
                if (nNum == 0) {
                    hInst.setText("Error: Must add a student to edit students.");
                }
                else {
                    editPanel.add(Title);
                    editPanel.add(Tag);
                    editPanel.add(display);
                    Tag.setText("Edit a student's marks.");
                    eHint.setText("Type 'back' to go back to the home screen.");

                    homePanel.setVisible(false);
                    editPanel.setVisible(true);

                    for (int i = 0; i < 50; i++) {
                        if (names[i] == null) {
                        break;
                        }
                        else {
                        markDisplay = markDisplay + names[i] + "<br>";
                        }
                    }
                     display.setText("<html>" + "Current students:<br>"+ markDisplay + "</html>");
                }
            }        
      });
      
      eOk.addActionListener(new ActionListener() {
            @Override	
            public void actionPerformed(ActionEvent arg0) {
                if ("back".equals(eInput.getText())) {
                    sNum = 1;
                    bAction = 0;
                    markDisplay = "";

                    eInput.setText("Student Name");
                    Tag.setText("Your smart student sorting solution!");
                    hInst.setText("Please select an action:");
                    homePanel.add(Title);
                    homePanel.add(Tag);

                    editPanel.setVisible(false);
                    homePanel.setVisible(true);

                    eInst.setText("Which student do you want to edit:");
                }
                else {
                if (bAction == 0) {
                    markDisplay = "";
                    String checkName = eInput.getText();
                    for (int i = 0; i < 50; i++) {
                        if (names[i] == null) {
                            eInst.setText("Error: Student does not exist.");
                            eInput.setText("");
                        }
                        else if (names[i].contains(checkName)) {
                            nTemp = i;
                            for (int x = 1; x < 50; x++) {
                                if (scores[i][x] == null) {
                                    break;
                                }
                                else {
                                    markDisplay = markDisplay + "Mark " + x + ": " + scores[i][x] + "%<br>";
                                }
                            }
                            display.setText("<html>" + names[i] + "'s marks:<br>" + markDisplay + "</html>");
                            eInst.setText("Do you want to [edit] or [add] a mark?");
                            eHint.setText("Type 'edit' to edit or 'add' to add.");
                            eInput.setText("");
                            bAction = 1;
                            break;
                        }
                    }
                }
                else if (bAction == 1) {
                    if ("edit".equals(eInput.getText())) {
                        eInst.setText("Which mark do you want to change?");
                        eInput.setText("");
                        bAction = 2;
                        eHint.setText("");
                    }
                    else if ("add".equals(eInput.getText())) {
                        for (int i = 0; i < 50; i++) {
                            if (scores[nTemp][i] == null) {
                                sTemp = i;
                                break;
                            }
                        }
                        eInst.setText("Enter " + names[nTemp] + "'s mark number " + sTemp + ":");
                        eInput.setText("");
                        bAction = 4;
                        eHint.setText("");
                    }
                    else {
                        eInst.setText("Error: Invalid input - try again.");
                        eInput.setText("");
                    }
                }
                else if (bAction == 2) {
                    sTemp = Integer.parseInt(eInput.getText());
                    
                    if (sTemp == 0) {
                        eInst.setText("Error: Invalid input - try again.");
                        eInput.setText("");
                    }
                    else {
                        if (scores[nTemp][sTemp] == null) {
                            eInst.setText("Error: Mark does not exist - try again.");
                            eInput.setText("");
                        }
                        else {
                            eInst.setText("Enter the updated mark (in %):");
                            eInput.setText("");
                            bAction = 3;
                        }
                    }
                }
                else if (bAction == 3) {
                    try {
                        scores[nTemp][sTemp] = Double.parseDouble(eInput.getText());
                        if (scores[nTemp][sTemp] > 100) {
                            eInst.setText("Error: Invalid mark - Try again.");
                            eInput.setText("");
                        }
                        else {
                            markDisplay = "";
                            for (int i = 0; i < 50; i++) {
                                if (names[i] == null) {
                                    break;
                                }
                                else {
                                    markDisplay = markDisplay + names[i] + "<br>";
                                }
                            }
                            display.setText("<html>" + "Current students:<br>"+ markDisplay + "</html>");
                        
                            eInst.setText("Which student do you want to edit:");
                            eInput.setText("Student Name");
                            bAction = 0;
                            eHint.setText(names[nTemp] + "'s mark has been updated.");
                        }
                    }
                    catch (NumberFormatException e) {
                        eInst.setText("Error: Invalid mark - Try again.");
                        eInput.setText("");
                    }
                }
                else if (bAction == 4) {
                    if ("done".equals(eInput.getText())) {
                        scores[nTemp][0] = new Double(sTemp - 1);

                            sNum = 1;
                            bAction = 0;
                            markDisplay = "";

                            eInput.setText("Student Name");
                            Tag.setText("Your smart student sorting solution!");
                            hInst.setText("Please select an action:");
                            homePanel.add(Title);
                            homePanel.add(Tag);

                            editPanel.setVisible(false);
                            homePanel.setVisible(true);

                            eInst.setText("Which student do you want to edit:");
                    }
                    else {
                        try {
                            scores[nTemp][sTemp] = Double.parseDouble(eInput.getText());
                            if (scores[nTemp][sTemp] > 100) {
                                eInst.setText("Error: Invalid mark - Try again.");
                                eInput.setText("");
                            }
                            else {
                                markDisplay = markDisplay + "Mark " + sTemp + ": " + scores[nTemp][sTemp] + "%<br>";
                                display.setText("<html>" + names[nTemp] + "'s marks:<br>" + markDisplay + "</html>");

                                sTemp++;

                                eInst.setText("Enter " + names[nTemp] + "'s mark number " + sTemp + ":");
                                eInput.setText("");
                                eHint.setText("(Type 'done' to go back.)");
                            }
                        }
                        catch (NumberFormatException e) {
                            eInst.setText("Error: Invalid mark - Try again.");
                            eInput.setText("");
                        }
                    }
                
                }
                }
            }        
      });
      
      //==========SORTING PAGE FUNCTIONALITY==========
      
      listStudent.addActionListener(new ActionListener() {
            @Override	
            public void actionPerformed(ActionEvent arg0) {
                if (nNum == 0) {
                    hInst.setText("Error: Must add a student to edit students.");
                }
                else {
                    listPanel.add(Title);
                    listPanel.add(Tag);
                    listPanel.add(display);
                    Tag.setText("List all students.");
                    lHint.setText("Click 'back' to go back to the home screen.");

                    homePanel.setVisible(false);
                    listPanel.setVisible(true);
                    
                    for (int i = 0; i < 50; i++) {
                        if (names[i] == null){
                            break;
                        } 
                        else {
                            avgs[i] = 0.0;
                            for (int x = 1; x < 50; x++) {
                                if (scores[i][x] == null) {
                                    break;
                                }
                                else {
                                    avgs[i] = avgs[i] + scores[i][x];
                                }
                            }
                            sortNames[i] = names[i];
                            avgs[i] = avgs[i] / scores[i][0];
                        }
                    }

                    for (int i = 0; i < 50; i++) {
                        if (names[i] == null) {
                        break;
                        }
                        else {
                        markDisplay = markDisplay + (i + 1) + ") " + names[i] + " - " + avgs[i] + "%<br>";
                        }
                    }
                    display.setText("<html>" + "Ordered by Date Added:<br>"+ markDisplay + "</html>");
                }
            }        
      });
      
      lBack.addActionListener(new ActionListener() {
            @Override	
            public void actionPerformed(ActionEvent arg0) {
                    bAction = 0;
                    markDisplay = "";

                    eInput.setText("Student Name");
                    Tag.setText("Your smart student sorting solution!");
                    hInst.setText("Please select an action:");
                    homePanel.add(Title);
                    homePanel.add(Tag);

                    listPanel.setVisible(false);
                    homePanel.setVisible(true);

                    eInst.setText("Which student do you want to edit:");
            }        
      });
      
      lAdded.addActionListener(new ActionListener() {
            @Override	
            public void actionPerformed(ActionEvent arg0) {
                    markDisplay = "";

                    for (int i = 0; i < 50; i++) {
                        if (names[i] == null) {
                        break;
                        }
                        else {
                        markDisplay = markDisplay + (i + 1) + ") " + names[i] + " - " + avgs[i] + "%<br>";
                        }
                    }
                    display.setText("<html>" + "Ordered by Date Added:<br>"+ markDisplay + "</html>");
            }        
      });
      
      lAverage.addActionListener(new ActionListener() {
            @Override	
            public void actionPerformed(ActionEvent arg0) {
                
                sortAvgs();
                
                markDisplay = "";
                for (int i = 0; i < 50; i++) {
                    if (avgs[i] == null) {
                        break;
                    }
                    else {
                        markDisplay = markDisplay + "<br>" + (i+1) + ") " + sortNames[i] + " - " + avgs[i] + "%";
                    }
                }
                
                display.setText("<html>" + "Ordered by Mark Average:" + markDisplay + "</html>");
            }        
      });
    }
    
    private void sortAvgs() {
        for (int i = 0; i < 50; i++) {
            if (avgs[i] == null) {
                break;
            }
            else if (avgs[i+1] == null) {
                break;
            }
            else {
                if (avgs[i] < avgs[i+1]) {
                    avgHolder = avgs[i];
                    namHolder = sortNames[i];
                    
                    avgs[i] = avgs[i+1];
                    sortNames[i] = sortNames[i+1];
                    
                    avgs[i+1] = avgHolder;
                    sortNames[i+1] = namHolder;
                    
                    sortAvgs();
                }
            }
        }
    }
    
    public static void main(String[] args) {
        new A3Q5SearchSort();
    }
    
}
