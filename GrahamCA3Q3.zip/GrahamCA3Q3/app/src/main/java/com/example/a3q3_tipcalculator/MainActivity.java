package com.example.a3q3_tipcalculator;
/*
ICS4UI
Swift U3A1Q3 - Array Question
Question: Make an app that can calculate the total price of a meal when the user inputs the desired tip amount.

EDIT LOG:
2019/05/15 - started, made GUI
2019/05/20 - worked on and finished actual functionality, added comments
*/

//Importing libraries
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private Button one;//Assigning GUI elements
    private Button two;
    private Button three;
    private Button four;
    private Button five;
    private Button six;
    private Button seven;
    private Button eight;
    private Button nine;
    private Button zero;
    private Button dot;
    private Button delete;
    private Button enter;

    private Button tip15;
    private Button tip18;
    private Button tip20;

    private Button again;

    private TextView display;
    private TextView instruct;
    private TextView reciept;

    private String displayText = "";//Variables for use in different functions
    private Double price = 0.0;
    private Double tip = 0.0;
    private boolean priceSet = false;
    private boolean tipSet = false;

    private static DecimalFormat df2 = new DecimalFormat("#.##");//for formatting prices


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setupUI();//sets up GUI

        one.setOnClickListener(new View.OnClickListener() {//button action listeners
            @Override
            public void onClick(View v) {
                updateDisplay("1");//function wich updates price display
            }
        });

        two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateDisplay("2");
            }
        });

        three.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateDisplay("3");
            }
        });

        four.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateDisplay("4");
            }
        });

        five.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateDisplay("5");
            }
        });

        six.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateDisplay("6");
            }
        });

        seven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateDisplay("7");
            }
        });

        eight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateDisplay("8");
            }
        });

        nine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateDisplay("9");
            }
        });

        zero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateDisplay("0");
            }
        });

        dot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateDisplay(".");
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {//delete button
            @Override
            public void onClick(View v) {
                if (display.getText() == "") {//do nothing if its empty

                } else {
                    displayText = displayText.substring(0, displayText.length() - 1);//creates a substring which removes the last char
                    display.setText(displayText);
                }
            }
        });

        tip15.setOnClickListener(new View.OnClickListener() {//15% tip
            @Override
            public void onClick(View v) {
                tip = price * 0.15;

                instruct.setText("(price) $" + df2.format(price) + " + (15%tip) $" + df2.format(tip));
                reciept.setText("Total: $" + df2.format(price + tip) );//updating displays to convey information
                display.setText("");

                one.setEnabled(false);//disabling all number buttons
                two.setEnabled(false);
                three.setEnabled(false);
                four.setEnabled(false);
                five.setEnabled(false);
                six.setEnabled(false);
                seven.setEnabled(false);
                eight.setEnabled(false);
                nine.setEnabled(false);
                zero.setEnabled(false);
                dot.setEnabled(false);
                delete.setEnabled(false);

                again.setEnabled(true);//enabling again button
            }
        });

        tip18.setOnClickListener(new View.OnClickListener() {//all same as above but 18%
            @Override
            public void onClick(View v) {
                tip = price * 0.18;

                instruct.setText("(price) $" + df2.format(price) + " + (18%tip) $" + df2.format(tip));
                reciept.setText("Total: $" + df2.format(price + tip) );
                display.setText("");

                one.setEnabled(false);
                two.setEnabled(false);
                three.setEnabled(false);
                four.setEnabled(false);
                five.setEnabled(false);
                six.setEnabled(false);
                seven.setEnabled(false);
                eight.setEnabled(false);
                nine.setEnabled(false);
                zero.setEnabled(false);
                dot.setEnabled(false);
                delete.setEnabled(false);

                again.setEnabled(true);
            }
        });

        tip20.setOnClickListener(new View.OnClickListener() {//all same as above but 20%
            @Override
            public void onClick(View v) {
                tip = price * 0.20;

                instruct.setText("(price) $" + df2.format(price) + " + (20%tip) $" + df2.format(tip));
                reciept.setText("Total: $" + df2.format(price + tip) );
                display.setText("");

                one.setEnabled(false);
                two.setEnabled(false);
                three.setEnabled(false);
                four.setEnabled(false);
                five.setEnabled(false);
                six.setEnabled(false);
                seven.setEnabled(false);
                eight.setEnabled(false);
                nine.setEnabled(false);
                zero.setEnabled(false);
                dot.setEnabled(false);
                delete.setEnabled(false);

                again.setEnabled(true);
            }
        });

        enter.setOnClickListener(new View.OnClickListener() {//enter button
            @Override
            public void onClick(View v) {
                if (priceSet) {//checks if the price is already set
                    checkInput();//price function

                    if (tipSet) {//if the tip was valid
                        instruct.setText("(price) $" + df2.format(price) + " + (tip) $" + df2.format(tip));
                        reciept.setText("Total: $" + df2.format(price + tip));//update display
                        display.setText("");

                        one.setEnabled(false);
                        two.setEnabled(false);
                        three.setEnabled(false);
                        four.setEnabled(false);
                        five.setEnabled(false);
                        six.setEnabled(false);
                        seven.setEnabled(false);//same as above, resets buttons, enables again button
                        eight.setEnabled(false);
                        nine.setEnabled(false);
                        zero.setEnabled(false);
                        dot.setEnabled(false);
                        delete.setEnabled(false);

                        again.setEnabled(true);
                    }

                } else {
                    checkInput();

                    if (priceSet) {//if the price was valud
                    instruct.setText("Enter the desired tip amount($) or click a tip %:");
                    reciept.setText("Total: (price) $" + displayText + " + (tip) $");
                    display.setText("");//updating displays
                    displayText = "";

                    tip15.setEnabled(true);
                    tip18.setEnabled(true);//enables tip buttons
                    tip20.setEnabled(true);
                    }
                }
            }
        });

        again.setOnClickListener(new View.OnClickListener() {//reset app button, puts everything back to its default state
            @Override
            public void onClick(View v) {
                displayText = "";
                display.setText(displayText);
                instruct.setText("Enter the price of your meal($):");
                reciept.setText("");
                price = 0.0;
                tip = 0.0;

                tip15.setEnabled(false);
                tip18.setEnabled(false);
                tip20.setEnabled(false);
                again.setEnabled(false);

                one.setEnabled(true);
                two.setEnabled(true);
                three.setEnabled(true);
                four.setEnabled(true);
                five.setEnabled(true);
                six.setEnabled(true);
                seven.setEnabled(true);
                eight.setEnabled(true);
                nine.setEnabled(true);
                zero.setEnabled(true);
                dot.setEnabled(true);
                delete.setEnabled(true);

                priceSet = false;
            }
        });

    }

    private void updateDisplay(String num) {//simple string update function
        displayText = displayText + num;
        display.setText(displayText);
    }

    private void checkInput() {//check to see if input is a double
        try {
            if (priceSet) {
                tip = Double.parseDouble(displayText);
                tipSet = true;
            } else {
                price = Double.parseDouble(displayText);
                priceSet = true;
            }
        }
        catch (NumberFormatException e) {
            reciept.setText("Invalid number, reenter and try again.");
        }
    }

    private void setupUI() {//placing GUI components
        one = (Button)findViewById(R.id.btn1);
        two = (Button)findViewById(R.id.btn2);
        three = (Button)findViewById(R.id.btn3);
        four = (Button)findViewById(R.id.btn4);
        five = (Button)findViewById(R.id.btn5);
        six = (Button)findViewById(R.id.btn6);
        seven = (Button)findViewById(R.id.btn7);
        eight = (Button)findViewById(R.id.btn8);
        nine = (Button)findViewById(R.id.btn9);
        zero = (Button)findViewById(R.id.btn0);

        dot = (Button)findViewById(R.id.dotbtn);
        delete = (Button)findViewById(R.id.delbtn);
        enter = (Button)findViewById(R.id.enterbtn);

        tip15 = (Button)findViewById(R.id.tip15);
        tip18 = (Button)findViewById(R.id.tip18);
        tip20 = (Button)findViewById(R.id.tip20);
        tip15.setEnabled(false);
        tip18.setEnabled(false);
        tip20.setEnabled(false);

        display = (TextView)findViewById(R.id.priceDisplay);
        instruct = (TextView)findViewById(R.id.priceDisplay2);
        reciept = (TextView)findViewById(R.id.priceDisplay3);

        again = (Button)findViewById(R.id.again);
        again.setEnabled(false);
    }
}
