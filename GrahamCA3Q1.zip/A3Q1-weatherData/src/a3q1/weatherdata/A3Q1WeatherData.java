/*
 * Unit 3 / Assignment 1 / Question 5
 * Graham Carkner - 05/14/2019
 * 
 * EDITS:
 * 05/14/18 - started basic functionality
 * 05/15/19 - worked on sorting and display
 * 05/20/19 - added comments
 */
package a3q1.weatherdata;

//automated imports as I needed them
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import java.nio.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;

public class A3Q1WeatherData {

    //Basic variables
    String weatherFile = "/Users/gcark/OneDrive/Documents/NetBeansProjects/eng-climate-summaries-All-4,2018.csv";
    BufferedReader br = null;
    String line = "";
    String csvSplitter = ",";

    //2-dimentional array of cities/values
    String[][] cities = new String[1082][25];

    //Functional variables
    int excluder = 0;
    int bAction = 0;
    
    A3Q1WeatherData() {
        JFrame f = new JFrame("WEATHER ACCESS+");
      
        //--Global GUI

        JLabel Title = new JLabel ("WEATHER ACCESS+");
        Title.setBounds(10, 10, 400, 50);
        Title.setFont(new Font("Arial", Font.BOLD, 20));

        JLabel Tag = new JLabel ("Your smart weather storing solution!");
        Tag.setBounds(10, 30, 400, 50);
        Tag.setFont(new Font("Arial", Font.PLAIN, 14));
        
        JLabel display = new JLabel("");
        display.setBounds(300, 0, 420, 330);
        display.setBorder(BorderFactory.createLineBorder(Color.black));
        display.setFont(new Font("Arial", Font.PLAIN, 14));
        display.setVerticalAlignment(JLabel.TOP);
        display.setVerticalTextPosition(JLabel.TOP);
        
        //--homePanel
        
        JPanel homePanel = new JPanel();
        homePanel.setSize(800,400);
        homePanel.setBackground(Color.white);
        homePanel.setVisible(true);
        homePanel.setLayout(null);
        
        JButton goButton = new JButton ("Start");
        goButton.setBounds(10, 180, 150, 30);
                
        JTextField searchBox = new JTextField ("");
        searchBox.setBounds(10, 130, 150, 30);
        searchBox.setVisible(false);
        
        JLabel hInst = new JLabel ("");
        hInst.setBounds(10, 70, 400, 50);
        hInst.setFont(new Font("Arial", Font.PLAIN, 14));
        
        homePanel.add(Title);
        homePanel.add(Tag);
        homePanel.add(goButton);
        homePanel.add(display);
        homePanel.add(hInst);
        homePanel.add(searchBox);

        //--Put into JFrame
        
        f.pack();
        f.add(homePanel);
        f.setSize(800,400);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setVisible(true);
    
    goButton.addActionListener(new ActionListener() {
            @Override	
            public void actionPerformed(ActionEvent arg0) {
                
                if (bAction == 0) {//inital button click

                    hInst.setText("Type in the name of your city:");
                    goButton.setText("Search");
                    searchBox.setVisible(true);
                    
                    getWeatherArray();

                    bAction = 1;
                }
                else if (bAction == 1) {//subsequent button click
                    boolean check = true;
                    String search  = searchBox.getText().toUpperCase();//get text from text field
                    
                    System.out.println(search);//for testing purposes
                    
                    for (int x = 0; x < cities.length; x++) {//searching through cities array
                        if (cities[x][0].contains(search)) {
                            display.setText("<html>" + "<u>" + cities[x][0] + 
                                    "</u><br>Province: " + cities[x][3] + "<br>" + 
                                            "Average Temp: " + cities[x][4] + "°C<br>" + 
                                                    "Total Percipitation: " + cities[x][14] + "mm</html>");//set display text to some city information
                            check = false;
                            break;
                        }
                    }
                    
                    if (check) {//if the city wasn't found
                        searchBox.setText("");
                        display.setText("That city did not exist. Please check spelling and try again.");//notify user that city doesn't exist
                    }
                }
            }     
      });
    }
    
    private void getWeatherArray() {
        int city = 0;//array index
        
        try {
            br = new BufferedReader(new FileReader(weatherFile));//buffering csv file
            while ((line = br.readLine()) != null) {
                if (excluder < 32) {//ignoring first 32 lines of document (aren't city data)
                    excluder++;
                }
                else {
                    String[] temp = line.split(csvSplitter);//split line into array on commas
                    
                    for (int i = 0; i < 25; i++) {
                        cities[city][i] = temp[i];//putting temporary array into permanent array
                    }

                    System.out.println(cities[city][0]);//for testing
                    city++;
                }
            }
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();//catch and printing errors
        }
        catch (IOException e) {
            e.printStackTrace();//same as above
        }
        finally {
            if (br != null) {
                try {
                    br.close();
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    
    public static void main(String[] args) {
        new A3Q1WeatherData();
    }
        
}
