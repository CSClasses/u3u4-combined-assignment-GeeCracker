/*
ICS4UI
Swift U3A1Q2 - Array Question
Question: write a program that takes an array of
unknown size containing ints and doubles, positive and negative numbers. Your task is to sort the array into three separate arrays of positive ints, positive doubles and all negatives. The original numbers are entered by the user, then displayed, then split and displayed again with appropriate titles for each.

EDIT LOG:
2019/05/06 - started and finished
*/

import Foundation

// defining arrays
var inArray: [Double] = []
var negArray: [Double] = []
var intArray: [Int] = []
var dubArray: [Double] = []

print("Please enter a list of numbers\nType 'd' when done\n")

var go = 0 //exit loop contition
while go == 0 {
  print("Next number:")
  let inp = readLine() //user input for the number

  if inp == "d" {//checking if they're done the list
    go = 1
  }
  else {
    if inp != nil {//checking if it can be unwrapped
      let unw = inp! //unwrapping
      if let check = (Double(unw)) { //checks if it can be turned into a double
        inArray.append(check) //appending numbr onto the array
      }
    }
  }
}

print("\nHere is your initial list:")
for n in 0..<inArray.count { //printing initial number list
  print(String(inArray[n]))
}

for n in 0..<inArray.count {
  if inArray[n] < 0 { //checking if the number is negative
    negArray.append(inArray[n])
  }
  else if (inArray[n] * 10).truncatingRemainder(dividingBy: 10) == 0 { //if the number * 10 % 10 is not 0, then it must be a double
    intArray.append(Int(inArray[n]))
  }
  else { // adding to double list
    dubArray.append(inArray[n])
  }
}

print("\nHere are the negative numbers:")
for n in 0..<negArray.count {
  print(negArray[n]) //printing all negative numbers
}

print("\nHere are the positive integers:")
for n in 0..<intArray.count {
  print(intArray[n]) //printing all ints
}

print("\nHere are the positive doubles:")
for n in 0..<dubArray.count {
  print(dubArray[n]) //printing all doubles
}